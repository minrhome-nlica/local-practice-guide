<?php
/**
 * Plugin Name: Mount County GenSen Rounded
 * Description: Loads licensed GenSen Rounded TW webfonts on all public Mount County pages.
 * Version: 1.0.0
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
add_action('wp_enqueue_scripts', static function () {
    $css = <<<'CSS'
/* Source font ButTaiwan/gensen-font, SIL OFL 1.1. The subset is served by the related guide site. */
@font-face {
  font-family: "MC GenSen Rounded";
  src: url("https://guide.mountcounty.com/fonts/GenSenRounded2TW-R.woff2") format("woff2");
  font-weight: 400 600;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "MC GenSen Rounded";
  src: url("https://guide.mountcounty.com/fonts/GenSenRounded2TW-B.woff2") format("woff2");
  font-weight: 601 900;
  font-style: normal;
  font-display: swap;
}
:root, body {
  --mc-site-font: "MC GenSen Rounded", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif;
  --theme-font-family: var(--mc-site-font);
  font-family: var(--mc-site-font) !important;
}
/* Target text nodes, preserving UI icon fonts, inline SVG and admin toolbar. */
body :is(#main, .entry-content, .ct-header, .ct-footer, .woocommerce, .woocommerce-page, .wp-site-blocks) {
  font-family: var(--mc-site-font) !important;
}
body :is(#main, .entry-content, .ct-header, .ct-footer, .woocommerce, .wp-site-blocks) :is(h1,h2,h3,h4,h5,h6,p,blockquote,figcaption,summary,li,dt,dd,th,td,label,button,input,textarea,select,a,strong,em,b,small,time) {
  font-family: var(--mc-site-font) !important;
}
body :is(#main, .entry-content, .ct-header, .ct-footer, .woocommerce, .wp-site-blocks) :is(.wp-block-button__link,.wp-element-button,.button,.price,.woocommerce-Price-amount,.ct-menu-link,.ct-header-text,.mc-brand-kicker,.mc-brand-tagline,.mc-site-banner,.mc-daily-journal,.mc-daily-chip) {
  font-family: var(--mc-site-font) !important;
}
CSS;
    wp_register_style('mountcounty-gensen-rounded', false, array(), '1.0.0');
    wp_enqueue_style('mountcounty-gensen-rounded');
    wp_add_inline_style('mountcounty-gensen-rounded', $css);
}, 99);
